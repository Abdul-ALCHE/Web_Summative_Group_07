from http.server import BaseHTTPRequestHandler, HTTPServer

RESPONSE = "Web Infrastructure - Group_07 - Server 1\n"

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        body = RESPONSE.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

if __name__ == "__main__":
    HTTPServer(("127.0.0.1", 3001), Handler).serve_forever()
